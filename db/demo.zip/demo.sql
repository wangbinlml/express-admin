-- ----------------------------
-- Table structure for `bs_login_log`
-- ----------------------------
DROP TABLE IF EXISTS `bs_login_log`;
CREATE TABLE `bs_login_log` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `user_name` varchar(64) NOT NULL,
  `name` varchar(64) NOT NULL,
  `ip` varchar(64) NOT NULL,
  `login_time` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of bs_login_log
-- ----------------------------
INSERT INTO `bs_login_log` VALUES ('3', '319', 'test', 'test', '::ffff:192.168.3.6', '2017-08-07 21:52:51');
INSERT INTO `bs_login_log` VALUES ('4', '319', 'test', 'test', '::ffff:192.168.3.6', '2017-08-07 21:59:14');
INSERT INTO `bs_login_log` VALUES ('5', '319', 'test', 'test', '223.72.87.133', '2017-08-07 22:01:26');
INSERT INTO `bs_login_log` VALUES ('6', '319', 'test', 'test', '::ffff:192.168.3.6', '2017-08-07 22:37:00');
INSERT INTO `bs_login_log` VALUES ('7', '319', 'test', 'test', '127.0.0.1', '2017-08-07 23:14:07');

-- ----------------------------
-- Table structure for `bs_menu`
-- ----------------------------
DROP TABLE IF EXISTS `bs_menu`;
CREATE TABLE `bs_menu` (
  `menu_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `parent_id` bigint(20) NOT NULL,
  `menu_name` varchar(20) NOT NULL,
  `menu_url` varchar(50) NOT NULL,
  `menu_icon` varchar(50) NOT NULL,
  PRIMARY KEY (`menu_id`),
  KEY `parent_id` (`parent_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=111 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of bs_menu
-- ----------------------------
INSERT INTO `bs_menu` VALUES ('1', '0', '我的控制台', '/', 'fa fa-dashboard');
INSERT INTO `bs_menu` VALUES ('5', '0', '系统管理', '#', 'glyphicon-certificate');
INSERT INTO `bs_menu` VALUES ('6', '5', '用户管理', '/users', 'glyphicon-user');
INSERT INTO `bs_menu` VALUES ('9', '5', '角色管理', '/roles', 'glyphicon-leaf');
INSERT INTO `bs_menu` VALUES ('10', '0', '权限管理', '#', 'glyphicon-lock');
INSERT INTO `bs_menu` VALUES ('11', '10', '用户角色管理', '/user_role', 'glyphicon-lock');
INSERT INTO `bs_menu` VALUES ('12', '10', '菜单权限管理', '/menu_role', 'glyphicon-lock');
INSERT INTO `bs_menu` VALUES ('13', '5', '菜单管理', '/menus', 'glyphicon-list-alt');
INSERT INTO `bs_menu` VALUES ('15', '0', 'Layout Options', '#', 'fa fa-files-o');
INSERT INTO `bs_menu` VALUES ('16', '15', ' Top Navigation', '#', '');
INSERT INTO `bs_menu` VALUES ('17', '15', ' Boxed', '#', '#');
INSERT INTO `bs_menu` VALUES ('18', '15', ' Fixed', '#', '');
INSERT INTO `bs_menu` VALUES ('19', '15', ' Collapsed Sidebar', '#', '');
INSERT INTO `bs_menu` VALUES ('23', '5', '操作日志', '/operation_log', '');
INSERT INTO `bs_menu` VALUES ('26', '5', '登录日志', '/login_log', '');
INSERT INTO `bs_menu` VALUES ('32', '10', '账号权限授权', '#', '');
INSERT INTO `bs_menu` VALUES ('35', '0', 'Charts', '#', 'fa fa-pie-chart');
INSERT INTO `bs_menu` VALUES ('38', '0', 'UI Elements', '#', 'fa fa-laptop');
INSERT INTO `bs_menu` VALUES ('41', '38', 'General', '#', '');
INSERT INTO `bs_menu` VALUES ('44', '35', ' ChartJS', '#', '');
INSERT INTO `bs_menu` VALUES ('47', '35', ' Morris', '#', '');
INSERT INTO `bs_menu` VALUES ('50', '38', 'Icons', '#', '');
INSERT INTO `bs_menu` VALUES ('53', '35', ' Flot', '#', '');
INSERT INTO `bs_menu` VALUES ('56', '35', ' Inline charts', '#', '');
INSERT INTO `bs_menu` VALUES ('59', '0', 'Forms', '#', 'fa fa-edit');
INSERT INTO `bs_menu` VALUES ('62', '59', 'General Elements', '#', '');
INSERT INTO `bs_menu` VALUES ('65', '59', 'Advanced Elements', '#', '');
INSERT INTO `bs_menu` VALUES ('68', '59', 'Editors', '#', '');
INSERT INTO `bs_menu` VALUES ('83', '0', 'Tables', '#', 'fa fa-table');
INSERT INTO `bs_menu` VALUES ('86', '83', 'Simple tables', '#', '');
INSERT INTO `bs_menu` VALUES ('89', '83', 'Data tables', '#', '');
INSERT INTO `bs_menu` VALUES ('103', '38', 'Buttons', '#', '');
INSERT INTO `bs_menu` VALUES ('104', '38', 'Sliders', '#', '');
INSERT INTO `bs_menu` VALUES ('108', '1', ' Dashboard v1', '#', '');
INSERT INTO `bs_menu` VALUES ('109', '1', ' Dashboard v2', '#', '');
INSERT INTO `bs_menu` VALUES ('110', '0', 'Widgets', '#', 'fa fa-th');

-- ----------------------------
-- Table structure for `bs_menu_role`
-- ----------------------------
DROP TABLE IF EXISTS `bs_menu_role`;
CREATE TABLE `bs_menu_role` (
  `menu_id` bigint(20) NOT NULL,
  `role_id` bigint(20) NOT NULL,
  PRIMARY KEY (`menu_id`,`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of bs_menu_role
-- ----------------------------
INSERT INTO `bs_menu_role` VALUES ('1', '1');
INSERT INTO `bs_menu_role` VALUES ('1', '2');
INSERT INTO `bs_menu_role` VALUES ('1', '8');
INSERT INTO `bs_menu_role` VALUES ('1', '11');
INSERT INTO `bs_menu_role` VALUES ('1', '14');
INSERT INTO `bs_menu_role` VALUES ('1', '999999901');
INSERT INTO `bs_menu_role` VALUES ('1', '999999902');
INSERT INTO `bs_menu_role` VALUES ('1', '999999903');
INSERT INTO `bs_menu_role` VALUES ('1', '999999904');
INSERT INTO `bs_menu_role` VALUES ('1', '999999906');
INSERT INTO `bs_menu_role` VALUES ('1', '999999910');
INSERT INTO `bs_menu_role` VALUES ('1', '999999914');
INSERT INTO `bs_menu_role` VALUES ('1', '999999917');
INSERT INTO `bs_menu_role` VALUES ('5', '1');
INSERT INTO `bs_menu_role` VALUES ('5', '11');
INSERT INTO `bs_menu_role` VALUES ('5', '14');
INSERT INTO `bs_menu_role` VALUES ('5', '999999903');
INSERT INTO `bs_menu_role` VALUES ('5', '999999914');
INSERT INTO `bs_menu_role` VALUES ('6', '1');
INSERT INTO `bs_menu_role` VALUES ('6', '11');
INSERT INTO `bs_menu_role` VALUES ('6', '14');
INSERT INTO `bs_menu_role` VALUES ('6', '999999903');
INSERT INTO `bs_menu_role` VALUES ('6', '999999914');
INSERT INTO `bs_menu_role` VALUES ('9', '1');
INSERT INTO `bs_menu_role` VALUES ('9', '11');
INSERT INTO `bs_menu_role` VALUES ('9', '999999914');
INSERT INTO `bs_menu_role` VALUES ('10', '1');
INSERT INTO `bs_menu_role` VALUES ('10', '11');
INSERT INTO `bs_menu_role` VALUES ('10', '14');
INSERT INTO `bs_menu_role` VALUES ('10', '999999901');
INSERT INTO `bs_menu_role` VALUES ('10', '999999903');
INSERT INTO `bs_menu_role` VALUES ('10', '999999914');
INSERT INTO `bs_menu_role` VALUES ('11', '1');
INSERT INTO `bs_menu_role` VALUES ('11', '11');
INSERT INTO `bs_menu_role` VALUES ('11', '14');
INSERT INTO `bs_menu_role` VALUES ('11', '999999914');
INSERT INTO `bs_menu_role` VALUES ('12', '1');
INSERT INTO `bs_menu_role` VALUES ('12', '11');
INSERT INTO `bs_menu_role` VALUES ('12', '999999914');
INSERT INTO `bs_menu_role` VALUES ('13', '1');
INSERT INTO `bs_menu_role` VALUES ('13', '11');
INSERT INTO `bs_menu_role` VALUES ('15', '1');
INSERT INTO `bs_menu_role` VALUES ('15', '5');
INSERT INTO `bs_menu_role` VALUES ('15', '8');
INSERT INTO `bs_menu_role` VALUES ('15', '11');
INSERT INTO `bs_menu_role` VALUES ('15', '14');
INSERT INTO `bs_menu_role` VALUES ('15', '999999901');
INSERT INTO `bs_menu_role` VALUES ('15', '999999902');
INSERT INTO `bs_menu_role` VALUES ('15', '999999904');
INSERT INTO `bs_menu_role` VALUES ('15', '999999907');
INSERT INTO `bs_menu_role` VALUES ('15', '999999914');
INSERT INTO `bs_menu_role` VALUES ('16', '1');
INSERT INTO `bs_menu_role` VALUES ('16', '5');
INSERT INTO `bs_menu_role` VALUES ('16', '14');
INSERT INTO `bs_menu_role` VALUES ('17', '1');
INSERT INTO `bs_menu_role` VALUES ('17', '5');
INSERT INTO `bs_menu_role` VALUES ('17', '8');
INSERT INTO `bs_menu_role` VALUES ('17', '11');
INSERT INTO `bs_menu_role` VALUES ('17', '14');
INSERT INTO `bs_menu_role` VALUES ('17', '999999901');
INSERT INTO `bs_menu_role` VALUES ('17', '999999902');
INSERT INTO `bs_menu_role` VALUES ('17', '999999904');
INSERT INTO `bs_menu_role` VALUES ('17', '999999907');
INSERT INTO `bs_menu_role` VALUES ('17', '999999914');
INSERT INTO `bs_menu_role` VALUES ('18', '1');
INSERT INTO `bs_menu_role` VALUES ('18', '5');
INSERT INTO `bs_menu_role` VALUES ('18', '8');
INSERT INTO `bs_menu_role` VALUES ('18', '11');
INSERT INTO `bs_menu_role` VALUES ('18', '14');
INSERT INTO `bs_menu_role` VALUES ('18', '999999901');
INSERT INTO `bs_menu_role` VALUES ('18', '999999902');
INSERT INTO `bs_menu_role` VALUES ('18', '999999904');
INSERT INTO `bs_menu_role` VALUES ('18', '999999907');
INSERT INTO `bs_menu_role` VALUES ('18', '999999914');
INSERT INTO `bs_menu_role` VALUES ('19', '1');
INSERT INTO `bs_menu_role` VALUES ('19', '5');
INSERT INTO `bs_menu_role` VALUES ('19', '8');
INSERT INTO `bs_menu_role` VALUES ('19', '11');
INSERT INTO `bs_menu_role` VALUES ('19', '14');
INSERT INTO `bs_menu_role` VALUES ('19', '999999901');
INSERT INTO `bs_menu_role` VALUES ('19', '999999902');
INSERT INTO `bs_menu_role` VALUES ('19', '999999904');
INSERT INTO `bs_menu_role` VALUES ('19', '999999907');
INSERT INTO `bs_menu_role` VALUES ('19', '999999914');
INSERT INTO `bs_menu_role` VALUES ('23', '1');
INSERT INTO `bs_menu_role` VALUES ('23', '11');
INSERT INTO `bs_menu_role` VALUES ('23', '14');
INSERT INTO `bs_menu_role` VALUES ('23', '999999914');
INSERT INTO `bs_menu_role` VALUES ('26', '1');
INSERT INTO `bs_menu_role` VALUES ('26', '11');
INSERT INTO `bs_menu_role` VALUES ('32', '1');
INSERT INTO `bs_menu_role` VALUES ('32', '11');
INSERT INTO `bs_menu_role` VALUES ('32', '14');
INSERT INTO `bs_menu_role` VALUES ('32', '999999901');
INSERT INTO `bs_menu_role` VALUES ('32', '999999903');
INSERT INTO `bs_menu_role` VALUES ('32', '999999914');
INSERT INTO `bs_menu_role` VALUES ('35', '1');
INSERT INTO `bs_menu_role` VALUES ('35', '5');
INSERT INTO `bs_menu_role` VALUES ('35', '11');
INSERT INTO `bs_menu_role` VALUES ('35', '14');
INSERT INTO `bs_menu_role` VALUES ('35', '999999901');
INSERT INTO `bs_menu_role` VALUES ('35', '999999907');
INSERT INTO `bs_menu_role` VALUES ('35', '999999910');
INSERT INTO `bs_menu_role` VALUES ('35', '999999914');
INSERT INTO `bs_menu_role` VALUES ('38', '1');
INSERT INTO `bs_menu_role` VALUES ('38', '5');
INSERT INTO `bs_menu_role` VALUES ('38', '11');
INSERT INTO `bs_menu_role` VALUES ('38', '14');
INSERT INTO `bs_menu_role` VALUES ('38', '999999901');
INSERT INTO `bs_menu_role` VALUES ('38', '999999914');
INSERT INTO `bs_menu_role` VALUES ('41', '1');
INSERT INTO `bs_menu_role` VALUES ('41', '5');
INSERT INTO `bs_menu_role` VALUES ('41', '11');
INSERT INTO `bs_menu_role` VALUES ('41', '14');
INSERT INTO `bs_menu_role` VALUES ('41', '999999901');
INSERT INTO `bs_menu_role` VALUES ('41', '999999914');
INSERT INTO `bs_menu_role` VALUES ('44', '1');
INSERT INTO `bs_menu_role` VALUES ('44', '5');
INSERT INTO `bs_menu_role` VALUES ('44', '11');
INSERT INTO `bs_menu_role` VALUES ('44', '14');
INSERT INTO `bs_menu_role` VALUES ('44', '999999901');
INSERT INTO `bs_menu_role` VALUES ('44', '999999907');
INSERT INTO `bs_menu_role` VALUES ('44', '999999910');
INSERT INTO `bs_menu_role` VALUES ('44', '999999914');
INSERT INTO `bs_menu_role` VALUES ('47', '1');
INSERT INTO `bs_menu_role` VALUES ('47', '5');
INSERT INTO `bs_menu_role` VALUES ('47', '11');
INSERT INTO `bs_menu_role` VALUES ('47', '14');
INSERT INTO `bs_menu_role` VALUES ('47', '999999901');
INSERT INTO `bs_menu_role` VALUES ('47', '999999907');
INSERT INTO `bs_menu_role` VALUES ('47', '999999910');
INSERT INTO `bs_menu_role` VALUES ('47', '999999914');
INSERT INTO `bs_menu_role` VALUES ('50', '1');
INSERT INTO `bs_menu_role` VALUES ('50', '5');
INSERT INTO `bs_menu_role` VALUES ('50', '14');
INSERT INTO `bs_menu_role` VALUES ('50', '999999901');
INSERT INTO `bs_menu_role` VALUES ('50', '999999914');
INSERT INTO `bs_menu_role` VALUES ('53', '1');
INSERT INTO `bs_menu_role` VALUES ('53', '5');
INSERT INTO `bs_menu_role` VALUES ('53', '11');
INSERT INTO `bs_menu_role` VALUES ('53', '14');
INSERT INTO `bs_menu_role` VALUES ('53', '999999901');
INSERT INTO `bs_menu_role` VALUES ('53', '999999907');
INSERT INTO `bs_menu_role` VALUES ('53', '999999910');
INSERT INTO `bs_menu_role` VALUES ('53', '999999914');
INSERT INTO `bs_menu_role` VALUES ('56', '1');
INSERT INTO `bs_menu_role` VALUES ('56', '5');
INSERT INTO `bs_menu_role` VALUES ('56', '11');
INSERT INTO `bs_menu_role` VALUES ('56', '14');
INSERT INTO `bs_menu_role` VALUES ('56', '999999901');
INSERT INTO `bs_menu_role` VALUES ('56', '999999907');
INSERT INTO `bs_menu_role` VALUES ('56', '999999910');
INSERT INTO `bs_menu_role` VALUES ('56', '999999914');
INSERT INTO `bs_menu_role` VALUES ('59', '1');
INSERT INTO `bs_menu_role` VALUES ('59', '5');
INSERT INTO `bs_menu_role` VALUES ('59', '11');
INSERT INTO `bs_menu_role` VALUES ('59', '14');
INSERT INTO `bs_menu_role` VALUES ('59', '999999901');
INSERT INTO `bs_menu_role` VALUES ('59', '999999902');
INSERT INTO `bs_menu_role` VALUES ('59', '999999904');
INSERT INTO `bs_menu_role` VALUES ('59', '999999906');
INSERT INTO `bs_menu_role` VALUES ('59', '999999914');
INSERT INTO `bs_menu_role` VALUES ('62', '1');
INSERT INTO `bs_menu_role` VALUES ('62', '5');
INSERT INTO `bs_menu_role` VALUES ('62', '11');
INSERT INTO `bs_menu_role` VALUES ('62', '14');
INSERT INTO `bs_menu_role` VALUES ('62', '999999914');
INSERT INTO `bs_menu_role` VALUES ('65', '1');
INSERT INTO `bs_menu_role` VALUES ('65', '5');
INSERT INTO `bs_menu_role` VALUES ('65', '11');
INSERT INTO `bs_menu_role` VALUES ('65', '14');
INSERT INTO `bs_menu_role` VALUES ('65', '999999914');
INSERT INTO `bs_menu_role` VALUES ('68', '1');
INSERT INTO `bs_menu_role` VALUES ('68', '5');
INSERT INTO `bs_menu_role` VALUES ('68', '11');
INSERT INTO `bs_menu_role` VALUES ('68', '14');
INSERT INTO `bs_menu_role` VALUES ('68', '999999914');
INSERT INTO `bs_menu_role` VALUES ('83', '1');
INSERT INTO `bs_menu_role` VALUES ('83', '5');
INSERT INTO `bs_menu_role` VALUES ('83', '8');
INSERT INTO `bs_menu_role` VALUES ('83', '11');
INSERT INTO `bs_menu_role` VALUES ('83', '14');
INSERT INTO `bs_menu_role` VALUES ('83', '999999901');
INSERT INTO `bs_menu_role` VALUES ('83', '999999902');
INSERT INTO `bs_menu_role` VALUES ('83', '999999904');
INSERT INTO `bs_menu_role` VALUES ('83', '999999914');
INSERT INTO `bs_menu_role` VALUES ('83', '999999917');
INSERT INTO `bs_menu_role` VALUES ('86', '1');
INSERT INTO `bs_menu_role` VALUES ('86', '5');
INSERT INTO `bs_menu_role` VALUES ('86', '8');
INSERT INTO `bs_menu_role` VALUES ('86', '11');
INSERT INTO `bs_menu_role` VALUES ('86', '14');
INSERT INTO `bs_menu_role` VALUES ('86', '999999901');
INSERT INTO `bs_menu_role` VALUES ('86', '999999902');
INSERT INTO `bs_menu_role` VALUES ('86', '999999904');
INSERT INTO `bs_menu_role` VALUES ('86', '999999914');
INSERT INTO `bs_menu_role` VALUES ('86', '999999917');
INSERT INTO `bs_menu_role` VALUES ('89', '1');
INSERT INTO `bs_menu_role` VALUES ('89', '5');
INSERT INTO `bs_menu_role` VALUES ('89', '8');
INSERT INTO `bs_menu_role` VALUES ('89', '11');
INSERT INTO `bs_menu_role` VALUES ('89', '14');
INSERT INTO `bs_menu_role` VALUES ('89', '999999901');
INSERT INTO `bs_menu_role` VALUES ('89', '999999902');
INSERT INTO `bs_menu_role` VALUES ('89', '999999904');
INSERT INTO `bs_menu_role` VALUES ('89', '999999914');
INSERT INTO `bs_menu_role` VALUES ('89', '999999917');
INSERT INTO `bs_menu_role` VALUES ('103', '1');
INSERT INTO `bs_menu_role` VALUES ('103', '5');
INSERT INTO `bs_menu_role` VALUES ('104', '1');
INSERT INTO `bs_menu_role` VALUES ('104', '5');
INSERT INTO `bs_menu_role` VALUES ('108', '1');
INSERT INTO `bs_menu_role` VALUES ('109', '1');
INSERT INTO `bs_menu_role` VALUES ('110', '1');

-- ----------------------------
-- Table structure for `bs_operation_logs`
-- ----------------------------
DROP TABLE IF EXISTS `bs_operation_logs`;
CREATE TABLE `bs_operation_logs` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `user_name` varchar(64) NOT NULL,
  `name` varchar(64) NOT NULL,
  `operations` varchar(128) NOT NULL,
  `operate_time` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of bs_operation_logs
-- ----------------------------
INSERT INTO `bs_operation_logs` VALUES ('4', '319', 'test', 'test', '更新用户：wanger;ID: 323', '2017-08-07 22:53:20');
INSERT INTO `bs_operation_logs` VALUES ('5', '319', 'test', 'test', '更新角色：客服;ID: 999999917', '2017-08-07 23:04:05');
INSERT INTO `bs_operation_logs` VALUES ('6', '319', 'test', 'test', '更新菜单：我的控制台;ID: 1', '2017-08-07 23:04:26');
INSERT INTO `bs_operation_logs` VALUES ('7', '319', 'test', 'test', '绑定角色ID:323;roles:11', '2017-08-07 23:07:02');
INSERT INTO `bs_operation_logs` VALUES ('8', '319', 'test', 'test', '绑定用户ID:323;roles:11,999999901', '2017-08-07 23:08:37');
INSERT INTO `bs_operation_logs` VALUES ('9', '319', 'test', 'test', '绑定菜单ID:5;roles:15,16,17,18,19,35,44,47,53,56,38,41,50,103,104,59,62,65,68,83,86,89', '2017-08-07 23:09:19');
INSERT INTO `bs_operation_logs` VALUES ('10', '319', 'test', 'test', '更新菜单：Charts;ID: 35', '2017-08-07 23:14:26');

-- ----------------------------
-- Table structure for `bs_role`
-- ----------------------------
DROP TABLE IF EXISTS `bs_role`;
CREATE TABLE `bs_role` (
  `role_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `role_name` varchar(10) NOT NULL,
  `description` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=999999938 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of bs_role
-- ----------------------------
INSERT INTO `bs_role` VALUES ('1', '管理员', '系统管理员');
INSERT INTO `bs_role` VALUES ('2', '普通用户', '系统中的普通用户角色');
INSERT INTO `bs_role` VALUES ('5', '客户经理', '客户经理');
INSERT INTO `bs_role` VALUES ('8', '客服', '客服');
INSERT INTO `bs_role` VALUES ('11', '运维', '运维');
INSERT INTO `bs_role` VALUES ('14', '运营支撑方', '运营支撑');
INSERT INTO `bs_role` VALUES ('999999901', '负责人', '客户管理员');
INSERT INTO `bs_role` VALUES ('999999902', '渠道代理SA', '渠道代理SA');
INSERT INTO `bs_role` VALUES ('999999903', '管理员', '渠道管理员');
INSERT INTO `bs_role` VALUES ('999999904', '普通客户经理', '普通客户经理');
INSERT INTO `bs_role` VALUES ('999999905', 'adminsc', '管理员账号');
INSERT INTO `bs_role` VALUES ('999999906', '硬件合作方', '硬件合作方角色');
INSERT INTO `bs_role` VALUES ('999999907', '运营人员', '观测数据');
INSERT INTO `bs_role` VALUES ('999999910', '大数据技术', '仅分配给大数据开发角色');
INSERT INTO `bs_role` VALUES ('999999914', '公司管理', '公司管理专用');
INSERT INTO `bs_role` VALUES ('999999917', '客服', '供客服使用');

-- ----------------------------
-- Table structure for `bs_user`
-- ----------------------------
DROP TABLE IF EXISTS `bs_user`;
CREATE TABLE `bs_user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(20) NOT NULL,
  `password` varchar(32) NOT NULL,
  `province` bigint(20) DEFAULT NULL,
  `city` bigint(20) DEFAULT NULL,
  `country` bigint(20) DEFAULT NULL,
  `name` varchar(40) NOT NULL,
  `mail` varchar(40) CHARACTER SET latin1 DEFAULT NULL,
  `tel` varchar(11) DEFAULT NULL,
  `sex` varchar(1) DEFAULT NULL,
  `birthday` date DEFAULT NULL,
  `channel_authorize_status` tinyint(4) DEFAULT '0' COMMENT '渠道授权状态：0：未授权；1：已授权',
  `own_supplier` bigint(20) DEFAULT NULL COMMENT '所属厂商ID',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=324 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of bs_user
-- ----------------------------
INSERT INTO `bs_user` VALUES ('20', 'admin', 'bVdi78gHGf5P1RATg6zEBw==', null, null, null, 'admin', '', '', '1', null, '0', null);
INSERT INTO `bs_user` VALUES ('23', 'usertest', '3T7MF3xqnrLyKZuD6tWkYw==', null, null, null, '测试用户', 'test@test.com', '12400012525', '1', '2017-08-04', '0', null);
INSERT INTO `bs_user` VALUES ('32', 'pp', 'Z+5y20CPsbK9yuEEk4GmlA==', null, null, null, '测试密码', '', '', '1', null, '0', null);
INSERT INTO `bs_user` VALUES ('41', 'qdSA1', '3T7MF3xqnrLyKZuD6tWkYw==', '130000', null, null, '渠道销售', '', '', '1', null, '1', null);
INSERT INTO `bs_user` VALUES ('44', 'qdSA2', '3T7MF3xqnrLyKZuD6tWkYw==', null, null, null, '渠道销售二', 'qdSA2@test.com', '13335685365', '0', '2017-08-04', '0', null);
INSERT INTO `bs_user` VALUES ('47', 'jl1', '3T7MF3xqnrLyKZuD6tWkYw==', null, null, null, '经理一', '', '', '1', null, '0', null);
INSERT INTO `bs_user` VALUES ('65', 'xjl1', '3T7MF3xqnrLyKZuD6tWkYw==', '520000', null, null, 'xjlyi', 'xjl1@test.com', '65252135', '1', null, '1', null);
INSERT INTO `bs_user` VALUES ('68', 'xjl2', '3T7MF3xqnrLyKZuD6tWkYw==', '520000', null, null, 'xjler', '', '65253255', '0', null, '0', null);
INSERT INTO `bs_user` VALUES ('71', 'xsa1', '3T7MF3xqnrLyKZuD6tWkYw==', '520000', null, null, 'xsayi', 'xsa1@io.com', '', '0', null, '1', null);
INSERT INTO `bs_user` VALUES ('74', 'xad1', '3T7MF3xqnrLyKZuD6tWkYw==', '520000', '520100', null, 'xadyi', 'xad1@test.com', '1651461', '1', null, '1', null);
INSERT INTO `bs_user` VALUES ('77', 'xad2', '3T7MF3xqnrLyKZuD6tWkYw==', '520000', '520100', '520102', 'xader', 'xad1@test.com', '', '0', null, '1', null);
INSERT INTO `bs_user` VALUES ('80', 'xad3', '3T7MF3xqnrLyKZuD6tWkYw==', '520000', null, null, 'xadssan', 'xad3@test.com', '', '1', null, '0', null);
INSERT INTO `bs_user` VALUES ('83', 'xfzr1', '3T7MF3xqnrLyKZuD6tWkYw==', '520000', null, null, 'xfzryi', 'xfzr1@test.com', '13718239054', '0', null, '1', null);
INSERT INTO `bs_user` VALUES ('86', 'gad1', '3T7MF3xqnrLyKZuD6tWkYw==', '520000', '520100', '520102', 'gadyi', 'gad1@test.com', '', '0', null, '0', null);
INSERT INTO `bs_user` VALUES ('89', 'gjl1', '3T7MF3xqnrLyKZuD6tWkYw==', '520000', '520100', null, 'gjlyi', '', '', '1', null, '1', null);
INSERT INTO `bs_user` VALUES ('92', 'gsa1', '3T7MF3xqnrLyKZuD6tWkYw==', '520000', '520100', null, 'gsayi', 'gsayi@test.com', '13522332092', '1', null, '1', null);
INSERT INTO `bs_user` VALUES ('95', 'gfzr1', '3T7MF3xqnrLyKZuD6tWkYw==', '520000', '520100', null, 'gfzryi', 'tet@test.cn', '13011231529', '0', '2017-08-07', '1', null);
INSERT INTO `bs_user` VALUES ('98', 'njl1', '3T7MF3xqnrLyKZuD6tWkYw==', '520000', '520100', '520102', 'njlyi', 'njl1@test.com', '52583655555', '1', null, '1', null);
INSERT INTO `bs_user` VALUES ('319', 'test', 'JIZzZ1X8jb6XVtPTEKaBfg==', null, null, null, 'test', 'test2@44.com', '13522662092', '1', '2017-08-03', '0', null);
INSERT INTO `bs_user` VALUES ('320', 'test21', '7jMQT7rU2AxwDZWXx96J6Q==', null, null, null, 'test1', 'test@123.com', '12312312311', '1', '2017-08-03', '0', null);
INSERT INTO `bs_user` VALUES ('321', 'zhangsan', '5vit1xT/bWLxjBZ4dp7/FQ==', null, null, null, 'zhangsan', '', '15252525865', '1', '2017-08-01', '0', null);
INSERT INTO `bs_user` VALUES ('322', 'lisi', '62NVO/Q34bdm8hH0qX3OEg==', null, null, null, 'lisi', 'lisi@test.com', '12325656987', '1', '2017-08-07', '0', null);
INSERT INTO `bs_user` VALUES ('323', 'wanger', '4GAUUL2IqUhcBY4edoe6Rg==', null, null, null, 'wanger', '12312@133.com', '123456', '0', '2017-09-07', '0', null);

-- ----------------------------
-- Table structure for `bs_user_role`
-- ----------------------------
DROP TABLE IF EXISTS `bs_user_role`;
CREATE TABLE `bs_user_role` (
  `user_id` bigint(20) NOT NULL,
  `role_id` bigint(20) NOT NULL,
  PRIMARY KEY (`user_id`,`role_id`),
  KEY `role_id` (`role_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of bs_user_role
-- ----------------------------
INSERT INTO `bs_user_role` VALUES ('20', '1');
INSERT INTO `bs_user_role` VALUES ('319', '1');
INSERT INTO `bs_user_role` VALUES ('23', '2');
INSERT INTO `bs_user_role` VALUES ('32', '2');
INSERT INTO `bs_user_role` VALUES ('47', '2');
INSERT INTO `bs_user_role` VALUES ('65', '2');
INSERT INTO `bs_user_role` VALUES ('68', '2');
INSERT INTO `bs_user_role` VALUES ('71', '2');
INSERT INTO `bs_user_role` VALUES ('74', '2');
INSERT INTO `bs_user_role` VALUES ('77', '2');
INSERT INTO `bs_user_role` VALUES ('80', '2');
INSERT INTO `bs_user_role` VALUES ('83', '2');
INSERT INTO `bs_user_role` VALUES ('86', '2');
INSERT INTO `bs_user_role` VALUES ('89', '2');
INSERT INTO `bs_user_role` VALUES ('92', '2');
INSERT INTO `bs_user_role` VALUES ('95', '2');
INSERT INTO `bs_user_role` VALUES ('98', '2');
INSERT INTO `bs_user_role` VALUES ('319', '2');
INSERT INTO `bs_user_role` VALUES ('26', '5');
INSERT INTO `bs_user_role` VALUES ('321', '8');
INSERT INTO `bs_user_role` VALUES ('323', '11');
INSERT INTO `bs_user_role` VALUES ('44', '14');
INSERT INTO `bs_user_role` VALUES ('83', '999999901');
INSERT INTO `bs_user_role` VALUES ('95', '999999901');
INSERT INTO `bs_user_role` VALUES ('320', '999999901');
INSERT INTO `bs_user_role` VALUES ('323', '999999901');
INSERT INTO `bs_user_role` VALUES ('41', '999999902');
INSERT INTO `bs_user_role` VALUES ('71', '999999902');
INSERT INTO `bs_user_role` VALUES ('92', '999999902');
INSERT INTO `bs_user_role` VALUES ('74', '999999903');
INSERT INTO `bs_user_role` VALUES ('77', '999999903');
INSERT INTO `bs_user_role` VALUES ('65', '999999904');
INSERT INTO `bs_user_role` VALUES ('89', '999999904');
INSERT INTO `bs_user_role` VALUES ('98', '999999904');
